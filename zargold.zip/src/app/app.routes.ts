import { Routes } from '@angular/router';

export const routes: Routes = [
  {path: '', redirectTo: 'radio-button', pathMatch: 'full'},
  {path:'radio-button', loadComponent: () => import("./radio-button/radio-button.component").then(m => m.RadioButtonComponent)},
];
  
//  pathMatch mean that url is full path
import { Routes } from '@angular/router';

export const routes: Routes = [
  // radial-button
  {path: '', redirectTo: 'radio-button', pathMatch: 'full'},
  {path:'radio-button', loadComponent: () => import("./../radio-button/radio-button.component").then(m => m.RadioButtonComponent)},


// app
// when set router cant use / for first it has settings
  {path: 'card', redirectTo: 'app-card', pathMatch: 'full'},
  {path:'app-card', loadComponent: () => import("./../card/card.component").then(m => m.CardComponent)},
];
